// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"or4r":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"WEtf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"xZJw":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = loadData;
var photo_years = d3.range(1930, 2014, 10);
var photo_steps = d3.range(1, 11);
var femaleArray = [];
var maleArray = [];
var photoArray = [];
var IDArray = [];
/* photo data */

function buildPhotoArray(number) {
  var photo1 = "".concat(number, "_1");
  var photo2 = "".concat(number, "_2");
  var photo3 = "".concat(number, "_3");
  var photo4 = "".concat(number, "_4");
  var photo5 = "".concat(number, "_5");
  var photo6 = "".concat(number, "_6");
  var photo7 = "".concat(number, "_7");
  var photo8 = "".concat(number, "_8");
  var photo9 = "".concat(number, "_9");
  var photo10 = "".concat(number, "_10");
  IDArray.push(photo1, photo2, photo3, photo4, photo5, photo6, photo7, photo8, photo9, photo10);
}

function setUpPhotoSteps() {
  photo_steps.forEach(function (d) {
    var femaleStep = "female_".concat(d, ".png");
    var maleStep = "male_".concat(d, ".png");
    femaleArray.push({
      femaleStep: femaleStep
    });
    maleArray.push({
      maleStep: maleStep
    });
  });
}

function setupPhotoData(number) {
  var decade = number.split('_')[0];
  var count = number.split('_')[1];
  var ID = number;
  var femalePhoto = "".concat(decade, "_female_").concat(count);
  var malePhoto = "".concat(decade, "_male_").concat(count);
  photoArray.push({
    ID: ID,
    decade: decade,
    femalePhoto: femalePhoto,
    malePhoto: malePhoto
  });
}
/* load year-by-year csvs */


function loadA(file) {
  return new Promise(function (resolve, reject) {
    d3.csv("assets/data/".concat(file)).then(function (result) {
      // clean here
      resolve(result);
    }).catch(reject);
  });
}

function loadData() {
  setUpPhotoSteps();
  photo_years.map(buildPhotoArray);
  IDArray.map(setupPhotoData);
  var loads = [loadA('trend_f_smoothed.csv'), loadA('trend_m_smoothed.csv'), photoArray];
  return Promise.all(loads);
}
},{}],"uDQA":[function(require,module,exports) {
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.puddingTrendLines = function init(options) {
  function createChart(el) {
    var $sel = d3.select(el);

    var _data = $sel.datum();

    var photoData = _data[1];
    _data = _data[0]; // dimension stuff

    var width = 0;
    var height = 0;
    var marginTop = 10;
    var marginBottom = 20;
    var marginLeft = 0;
    var marginRight = 0; // data

    var dataByGender = null;
    var femaleData = null;
    var maleData = null; // scales

    var maxX = null;
    var minX = null;
    var maxY = null;
    var minY = null;
    var xScale = d3.scaleLinear();
    var xAxis = null;
    var xAxisGroup = null;
    var yScale = d3.scaleLinear();
    var yAxis = null;
    var yAxisGroup = null;
    var axisPadding = 15;
    var genderLines = null;
    var lineGroup = null;
    var femaleLine = null;
    var maleLine = null;
    var genderArea = null;
    var drawArea = null;
    var numTicks = null; // dom elements

    var $svg = null;
    var $axis = null;
    var $vis = null;
    var $biggerLabel = null;
    var $smallerLabel = null;
    var $biggerLabelGroup = null;
    var $smallerLabelGroup = null;
    var $upArrow = null;
    var $downArrow = null;
    var $fLabel = null;
    var $mLabel = null;
    var $tooltip = null;
    var $vertical = null;
    var $fPhotoContainer = d3.select('.f-photos');
    var $mPhotoContainer = d3.select('.m-photos');
    var $decadeText = d3.selectAll('.chart .decade');
    var $fPhoto = null;
    var $mPhoto = null; // interactions

    var $mouse = null;
    var $mouseX = null;
    var $mouseY = null; // helper functions

    function structureData() {
      _data = _data.map(function (d) {
        return _objectSpread({}, d, {
          med: +d.med,
          smoothed: +d.smoothed,
          flat: +d.flat,
          discrim: +d.discrim,
          discrimSmoothA: +d.discrimSmoothA,
          discrimSmoothB: +d.discrimSmoothB,
          year: +d.year
        });
      });
      maxY = d3.max(_data, function (d) {
        return d.smoothed;
      });
      minY = d3.min(_data, function (d) {
        return d.smoothed;
      });
      maxX = d3.max(_data, function (d) {
        return d.year;
      });
      minX = d3.min(_data, function (d) {
        return d.year;
      });
      dataByGender = d3.nest().key(function (d) {
        return d.gender;
      }).entries(_data);
      dataByYear = d3.nest().key(function (d) {
        return d.year;
      }).rollup(function (values) {
        return {
          male: values.find(function (v) {
            return v.gender == "Male";
          }).smoothed,
          female: values.find(function (v) {
            return v.gender == "Female";
          }).smoothed
        };
      }).entries(_data);
      femaleData = _data.filter(function (d) {
        return d.gender == 'Female';
      });
      maleData = _data.filter(function (d) {
        return d.gender == 'Male';
      });
    }

    function getTicks(w) {
      if (w > 640) {
        numTicks = 10;
      } else {
        numTicks = 5;
      }
    }

    function syncDecade(year) {
      if (year >= 1930 && year < 1940) {
        return 1930;
      }

      if (year >= 1940 && year < 1950) {
        return 1940;
      }

      if (year >= 1950 && year < 1960) {
        return 1950;
      }

      if (year >= 1960 && year < 1970) {
        return 1960;
      }

      if (year >= 1970 && year < 1980) {
        return 1970;
      }

      if (year >= 1980 && year < 1990) {
        return 1980;
      }

      if (year >= 1990 && year < 2000) {
        return 1990;
      }

      if (year >= 2000 && year < 2010) {
        return 2000;
      }

      if (year >= 2010 && year < 2020) {
        return 2010;
      }
    }

    function appendPhotos(match) {
      // console.log(match.year)
      //
      var decadeMatch = syncDecade(match.year);
      $fPhoto = $fPhotoContainer.selectAll('img');
      $fPhoto.attr('src', function (d, i) {
        return "assets/images/avgs_decade/".concat(decadeMatch, "_female_").concat(i + 1, ".png");
      }).attr('alt', "".concat(decadeMatch, "s women's yearbook photo"));
      $mPhoto = $mPhotoContainer.selectAll('img');
      $mPhoto.attr('src', function (d, i) {
        return "assets/images/avgs_decade/".concat(decadeMatch, "_male_").concat(i + 1, ".png");
      }).attr('alt', "".concat(decadeMatch, "s men's yearbook photo"));
      $decadeText.text("".concat(decadeMatch, "s"));
    }

    function lineMouseMove(d) {
      $mouse = d3.mouse(this);
      $mouseX = $mouse[0];
      $mouseY = $mouse[1];
      var invertedX = Math.round(xScale.invert($mouseX));
      var invertedY = yScale.invert($mouseY);
      var year = invertedX.toString();
      var match = d[0].find(function (v) {
        return v.year === year;
      });
      var fData = d[0].filter(function (d) {
        return d.gender == 'Female';
      });
      var fMatch = fData.find(function (v) {
        return v.year === year;
      });
      var fNum = (+fMatch.smoothed).toFixed(3);
      var mData = d[0].filter(function (d) {
        return d.gender == 'Male';
      });
      var mMatch = mData.find(function (v) {
        return v.year === year;
      });
      var mNum = (+mMatch.smoothed).toFixed(3);
      var right = $mouseX > window.innerWidth / 2;
      var offset = right ? $tooltip.node().offsetWidth + 10 : -10;
      appendPhotos(match);
      $tooltip.classed('is-visible', true).style('top', "".concat($mouseY, "px")).style('left', "".concat($mouseX - offset, "px")).html(function (d) {
        return "<div class='year'>\n\t\t\t\t\t\t<p>".concat(invertedX, "</p>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class='f-tip'>\n\t\t\t\t\t\t<div class='line'></div>\n\t\t\t\t\t\t<p>Women: ").concat(fNum, "</p>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class='m-tip'>\n\t\t\t\t\t\t<div class='line'></div>\n\t\t\t\t\t\t<p>Men: ").concat(mNum, "</p>\n\t\t\t\t\t</div>");
      });
      $vertical.classed('is-visible', true).style('left', "".concat($mouseX, "px")).style('bottom', '29px');
    }

    function lineMouseOut(d) {
      $tooltip.classed('is-visible', false);
      $vertical.classed('is-visible', false);
    }

    var Chart = {
      // called once at start
      init: function init() {
        structureData();
        $tooltip = d3.selectAll('.chart figure').append('div').attr('class', 'tooltip');
        $vertical = d3.selectAll('.chart figure').append('div').attr('class', 'vertical');
        $svg = $sel.append('svg').attr('class', 'pudding-chart');
        $axis = $svg.append('g').attr('class', 'g-axis');
        var $g = $svg.append('g'); // offset chart for margins

        $g.attr('transform', "translate(".concat(marginLeft, ", ").concat(marginTop, ")")); // create axis

        xAxisGroup = $axis.append('g').attr('class', 'x axis');
        yAxisGroup = $axis.append('g').attr('class', 'y axis');
        $fLabel = $g.append('text').attr('class', 'f-label').text('Women');
        $mLabel = $g.append('text').attr('class', 'm-label').text('Men');
        $biggerLabelGroup = $svg.append('g');
        $smallerLabelGroup = $svg.append('g');
        $biggerLabel = $biggerLabelGroup.append('text').text('Bigger median hair').attr('class', 'axis-label bigger-axis-label');
        $smallerLabel = $smallerLabelGroup.append('text').text('Smaller median hair').attr('class', 'axis-label smaller-axis-label');
        $upArrow = $biggerLabelGroup.append('svg:image').attr('xlink:href', "assets/images/arrow-up.svg").attr('width', '20px').attr('height', '20px');
        $downArrow = $smallerLabelGroup.append('svg:image').attr('xlink:href', "assets/images/arrow-down.svg").attr('width', '20px').attr('height', '20px'); // setup viz group

        $vis = $g.append('g').attr('class', 'g-vis');
        lineGroup = $svg.select('.g-vis');
        femaleLine = lineGroup.append('path').datum(femaleData).attr('class', 'Female');
        maleLine = lineGroup.append('path').datum(maleData).attr('class', 'Male');
        drawArea = $vis.append('path').datum(dataByYear).attr('class', 'area');
        Chart.resize();
        Chart.render();
      },
      // on resize, update new dimensions
      resize: function resize() {
        // defaults to grabbing dimensions from container element
        width = $sel.node().offsetWidth - marginLeft - marginRight;
        height = $sel.node().offsetHeight - marginTop - marginBottom;
        $svg.attr('width', width + marginLeft + marginRight).attr('height', height + marginTop + marginBottom);
        getTicks(width);
        xScale.domain([minX, maxX]).range([0, width]);
        yScale.domain([0, maxY]).range([height, 0]);
        xAxis = d3.axisBottom(xScale).tickPadding(axisPadding).ticks(numTicks).tickFormat(d3.format('d'));
        yAxis = d3.axisLeft(yScale).tickPadding(axisPadding).tickSize(-width).ticks(8);
        $axis.select('.x').attr('transform', "translate(".concat(marginLeft, ",").concat(height - marginBottom + axisPadding, ")")).call(xAxis);
        $axis.select('.x.axis .tick text').attr('transform', "translate(20,0)");
        $axis.select('.y').attr('transform', "translate(".concat(marginLeft, ",0)")).call(yAxis);
        genderLines = d3.line().x(function (d) {
          return xScale(d.year);
        }).y(function (d) {
          return yScale(d.smoothed);
        });
        maleLine.attr('d', genderLines);
        femaleLine.attr('d', genderLines);
        genderArea = d3.area().x(function (d) {
          return xScale(d.key);
        }).y0(function (d) {
          return yScale(d.value.female);
        }).y1(function (d) {
          return yScale(d.value.male);
        });
        drawArea.attr('d', genderArea);
        $svg.on('mousemove', lineMouseMove).on('mouseover', lineMouseMove).on('mouseout', lineMouseOut);
        $fLabel.attr('x', width).attr('y', 30);
        $mLabel.attr('x', 0).attr('y', height / 1.5);
        $biggerLabelGroup.attr('transform', "translate(0,".concat(axisPadding * 1.5, ")"));
        $biggerLabel.attr('transform', "translate(25,0)");
        $upArrow.attr('transform', "translate(0,-15)");
        $smallerLabelGroup.attr('transform', "translate(0,".concat(height - axisPadding / 2, ")"));
        $smallerLabel.attr('transform', "translate(25,0)");
        $downArrow.attr('transform', "translate(0,-15)");
        return Chart;
      },
      // update scales and render chart
      render: function render() {
        return Chart;
      },
      // get / set data
      data: function data(val) {
        if (!arguments.length) return _data;
        _data = val;
        $sel.datum(_data);
        Chart.render();
        return Chart;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{}],"TAPd":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

require("./pudding-chart/line");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var femaleTrendData = null;
var maleTrendData = null;
var genderTrendData = null;
var photoData = null;
var combinedData = [];
var chartTrends = null;
var $trendLines = d3.select('.chart figure');
var $seeMoreButton = d3.select('.methods__button');
var $methodsText = d3.select('.methods__text');
var $fade = d3.select('.methods__fade');

function resize() {
  chartTrends.resize();
}

function setupTrendLines(data) {
  chartTrends = $trendLines.datum(data).puddingTrendLines();
}

function handleSeeMore() {
  $methodsText.style('height', 'auto');
  $fade.classed('is-visible', false);
  $seeMoreButton.classed('is-visible', false);
}

function init() {
  (0, _loadData.default)().then(function (result) {
    femaleTrendData = result[0];
    maleTrendData = result[1];
    genderTrendData = femaleTrendData.concat(maleTrendData);
    photoData = result[2];
    combinedData.push(genderTrendData, photoData);
    setupTrendLines(combinedData);
    $seeMoreButton.on('click', handleSeeMore);
  });
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./load-data":"xZJw","./pudding-chart/line":"uDQA"}],"v9Q8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var fallbackData = [{
  image: '2018_02_stand-up',
  url: '2018/02/stand-up',
  hed: 'The Structure of Stand-Up Comedy'
}, {
  image: '2018_04_birthday-paradox',
  url: '2018/04/birthday-paradox',
  hed: 'The Birthday Paradox Experiment'
}, {
  image: '2018_11_boy-bands',
  url: '2018/11/boy-bands',
  hed: 'Internet Boy Band Database'
}, {
  image: '2018_08_pockets',
  url: '2018/08/pockets',
  hed: 'Women’s Pockets are Inferior'
}];
var storyData = null;

function loadJS(src, cb) {
  var ref = document.getElementsByTagName('script')[0];
  var script = document.createElement('script');
  script.src = src;
  script.async = true;
  ref.parentNode.insertBefore(script, ref);

  if (cb && typeof cb === 'function') {
    script.onload = cb;
  }

  return script;
}

function loadStories(cb) {
  var request = new XMLHttpRequest();
  var v = Date.now();
  var url = "https://pudding.cool/assets/data/stories.json?v=".concat(v);
  request.open('GET', url, true);

  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText);
      cb(data);
    } else cb(fallbackData);
  };

  request.onerror = function () {
    return cb(fallbackData);
  };

  request.send();
}

function createLink(d) {
  return "\n\t<a class='footer-recirc__article' href='https://pudding.cool/".concat(d.url, "' target='_blank'>\n\t\t<img class='article__img' src='https://pudding.cool/common/assets/thumbnails/640/").concat(d.image, ".jpg' alt='").concat(d.hed, "'>\n\t\t<p class='article__headline'>").concat(d.hed, "</p>\n\t</a>\n\t");
}

function recircHTML() {
  var url = window.location.href;
  var html = storyData.filter(function (d) {
    return !url.includes(d.url);
  }).slice(0, 4).map(createLink).join('');
  d3.select('.pudding-footer .footer-recirc__articles').html(html);
}

function init() {
  loadStories(function (data) {
    storyData = data;
    recircHTML();
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"epB2":[function(require,module,exports) {
"use strict";

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _graphic = _interopRequireDefault(require("./graphic"));

var _footer = _interopRequireDefault(require("./footer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var $body = d3.select('body');
var previousWidth = 0;

function resize() {
  // only do resize on width changes, not height
  // (remove the conditional if you want to trigger on height change)
  var width = $body.node().offsetWidth;

  if (previousWidth !== width) {
    previousWidth = width;

    _graphic.default.resize();
  }
}

function setupStickyHeader() {
  var $header = $body.select('header');

  if ($header.classed('is-sticky')) {
    var $menu = $body.select('.header__menu');
    var $toggle = $body.select('.header__toggle');
    $toggle.on('click', function () {
      var visible = $menu.classed('is-visible');
      $menu.classed('is-visible', !visible);
      $toggle.classed('is-visible', !visible);
    });
  }
}

function init() {
  // add mobile class to body tag
  $body.classed('is-mobile', _isMobile.default.any()); // setup resize event

  window.addEventListener('resize', (0, _lodash.default)(resize, 150)); // setup sticky header menu

  setupStickyHeader(); // kick off graphic code

  _graphic.default.init(); // load footer stories


  _footer.default.init();
}

init();
},{"lodash.debounce":"or4r","./utils/is-mobile":"WEtf","./graphic":"TAPd","./footer":"v9Q8"}]},{},["epB2"], null)
//# sourceMappingURL=/main.js.map